# Section Blueprints

Use these blueprints to draft or revise paper sections in the local INFOCOM Wi-Fi sensing style.

## Abstract

Preferred 5-part order:

1. domain value and application context
2. exact limitation of current systems
3. system name plus core idea
4. one or two technical mechanisms
5. prototype and quantitative result

Compact formula:

`Wi-Fi sensing enables X, but existing systems fail at Y because of Z. This paper presents SYSTEM, which solves the problem by A and B. We implement SYSTEM on commodity devices and show RESULT.`

## Introduction

### Background and Motivation

Paragraph goals:

1. explain why the task matters in smart homes, healthcare, privacy, or automation
2. explain why Wi-Fi sensing is attractive compared with more intrusive modalities
3. narrow from broad value to the specific missing capability

### Gap Statement

Turn the gap into one deployment-critical sentence, for example:

- existing systems assume calibration that real homes do not provide
- single-modal tracking drifts over time
- limited devices make prior solutions impractical
- current research improves accuracy but ignores security
- integrating separate sensing tasks does not scale

### Basic Idea or Nutshell

This section should answer:

- what is the conceptual pivot?
- what signal or feature is exploited?
- why does that pivot directly attack the gap?

Keep it system-level. Save derivations for later sections.

### Challenges and Solutions

Use 2 to 3 challenge-solution pairs. Good format:

- `Challenge 1:` explain why the problem is hard
- `Solution 1:` name the insight and resulting mechanism

Make each challenge a different type:

- observability
- computation
- synchronization
- initialization
- security
- scalability

### Contributions

Prefer parallel bullets:

- `Model or theory:` what new physical, mathematical, or conceptual model is introduced
- `Method or system:` what pipeline, algorithm, or architecture is built
- `Implementation or evaluation:` what prototype was built and what high-level result was achieved

## Preliminary

The local corpus uses preliminaries to arm the reader with exactly the signal relationships needed later. Do not turn this section into a textbook survey.

Include:

- one compact signal model equation
- 2 to 4 features that the paper will reuse later
- one sentence per feature explaining what it reveals physically
- a figure or observation if available

## Basic Idea or System Overview

This section should bridge theory and architecture.

Good contents:

- the observation or experimental hint that justifies the design
- the decomposition into stages
- the input and output of each stage
- the reason this decomposition reduces ambiguity, cost, or drift

## System Design

Write each module with the same discipline:

1. restate the local problem the module solves
2. specify input and output
3. explain the model or algorithm
4. tie the output to the next module
5. remind the reader which introduction challenge is being resolved

For multimodal papers, avoid presenting fusion as generic concatenation. Explain what each modality contributes that the other cannot.

## Implementation and Evaluation

Default order:

1. implementation setup
2. overall performance
3. comparative analysis
4. parameter study
5. ablation or case study

Implementation paragraphs should usually mention:

- hardware type
- number of transceivers or microphones if relevant
- packet or sampling rate if relevant
- software stack or CSI tool if relevant
- deployment scenarios

## Conclusion

Keep it short. Re-state:

- the problem
- the system's main idea
- one practical outcome

Avoid introducing new claims in the conclusion.
