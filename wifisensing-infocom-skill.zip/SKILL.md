---

## name: wifisensing-infocom-skill
description: Draft or revise INFOCOM-style Wi-Fi sensing papers using the narrative, logic, and writing patterns distilled from the local reference_infocom_papers corpus. Use when writing abstracts, introductions, preliminaries, system design, evaluation, or overall paper framing for CSI, device-free sensing, tracking, localization, multimodal fusion, or secure sensing work.

# Wi-FiSensing Infocom Skill

## Overview

Use this skill when the user wants to write, rewrite, structure, or critique a Wi-Fi sensing paper in the style of the local INFOCOM reference set. The target style is not generic academic prose; it is a specific Tianjin-style Wi-Fi sensing paper pattern built around deployment motivation, physical intuition, challenge-solution decomposition, and commodity-device validation.

This skill is optimized for papers that resemble the local corpus:

- device-free sensing with CSI or Doppler-derived features
- user tracking or localization
- multimodal Wi-Fi fusion with acoustic or other sensing
- unified sensing frameworks
- secure or privacy-preserving wireless sensing

## Minimal Workflow

1. Identify the paper type before writing.
  Use [references/corpus-patterns.md](./references/corpus-patterns.md) to map the work to one of these shapes: single-task system, multimodal fusion system, calibration/localization system, unified framework, or secure sensing defense.
2. Build the narrative spine before drafting sentences.
  Every paper in this corpus starts from an application pull, then exposes one concrete deployment gap, then narrows to two or three technical challenges, then answers each challenge with a named mechanism.
3. Draft sections in INFOCOM order rather than idea order.
  The corpus strongly prefers: Abstract -> Introduction -> Preliminary -> Basic Idea or System Overview -> System Design -> Implementation and Evaluation -> Related Work -> Conclusion.
4. Tie every major module back to a physical or systems constraint.
  Avoid presenting modules as arbitrary engineering blocks. Each module should exist because it resolves a challenge already established in the introduction.
5. Close the story with commodity deployment and quantitative evidence.
  The corpus almost always ends the front matter with a prototype claim on commercial off-the-shelf devices and a compact performance summary.

## Writing Rules

### Introduction

Write introductions as a sequence of moves, not a literature dump:

1. Start with smart-home, elderly-care, privacy, or ubiquitous-service value.
2. State why Wi-Fi sensing is attractive: device-free, low-cost, already deployed, privacy-friendlier than vision.
3. Introduce the exact practical gap.
  Examples: manual calibration, cumulative drift, limited devices, missing initial position, lack of security, lack of extensibility.
4. Narrow the gap to mechanism-level causes.
  Examples: coupled variables, weak footsteps, asynchronous modalities, time-varying phase noise, unauthorized eavesdropping.
5. Present the system as a direct response to those causes.
6. Enumerate two or three challenges and pair each with a specific solution.
7. End with contribution bullets and a paper roadmap.

### Challenge-Solution Style

For each challenge:

- name the challenge in one compact phrase
- explain why prior methods fail in deployment, cost, scalability, or physical fidelity
- introduce one core insight with explicit causality
- map that insight to a named algorithm, feature, or pipeline

Good local rhythm:

- `Challenge:` coupled dependency, weak signal, computational cost, delay, limited devices
- `Insight:` reconstruct features, exploit shared paths, fuse complementary modalities, search over lower-dimensional candidates
- `Mechanism:` alternating iteration, pace detection, behavior codebook, forward model network, sliding windows

### Section Logic

- `Preliminary` should define the signal model, not just notation.
- `Basic Idea` should surface observations that motivate the architecture.
- `System Overview` should show stage decomposition and data flow.
- `System Design` should explain inputs, outputs, and why each module resolves a prior challenge.
- `Evaluation` should begin with implementation details and then move to overall performance before parameters or ablations.

### Tone and Diction

Prefer concrete, slightly assertive system prose:

- emphasize `commercial off-the-shelf (COTS)` or `commodity devices`
- repeatedly connect methods to `practical deployment`, `low effort`, `limited devices`, or `real-world scenarios`
- use short claim sentences before equations or detailed derivations
- favor explicit transitions such as `Specifically`, `Accordingly`, `To address this challenge`, `Our insight is`, and `Based on`

Do not overdo novelty language. The corpus sounds confident, but it usually grounds novelty in one of three forms:

- a new physical model
- a new fusion or reconstruction pipeline
- a new system capability under realistic deployment constraints

## Section-by-Section Drafting

Use [references/section-blueprints.md](./references/section-blueprints.md) when the user asks for a concrete section draft. It contains compact blueprints for:

- abstract
- introduction
- preliminaries
- basic idea or system overview
- system design
- implementation and evaluation
- contribution bullets

## Corpus Use

Use [references/corpus-patterns.md](./references/corpus-patterns.md) when you need the distilled evidence behind this skill. It summarizes the five local reference papers:

- `AutoLoc`
- `DuTrack`
- `Secur-Fi`
- `UNI-FI`
- `WSTrack`

Load only the specific reference file you need. Keep the main skill lean.

## Output Expectations

When using this skill to write or revise text:

- preserve the user's actual technical contribution instead of forcing it to mimic a paper it is not
- keep equations and signal features tightly coupled to the story
- prefer 2 to 3 major challenges in the introduction
- make contributions parallel in structure: theory or model, algorithm or system, implementation or evaluation
- if the work does not include a real prototype, do not fabricate COTS deployment claims; instead, explicitly flag the gap

