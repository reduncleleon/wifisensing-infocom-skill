# Corpus Patterns

This reference distills the shared narrative and writing logic from the local INFOCOM Wi-Fi sensing corpus:

- `AutoLoc`
- `DuTrack`
- `Secur-Fi`
- `UNI-FI`
- `WSTrack`

## 1. What This Corpus Optimizes For

These papers are not written as purely theoretical papers and not as purely black-box ML papers. Their dominant pattern is:

1. start from a strong deployment motivation
2. reduce the problem to a concrete technical bottleneck
3. explain the bottleneck through wireless or multimodal physics
4. propose one system whose modules each answer a named challenge
5. validate on commodity hardware in realistic scenarios

The reader is meant to feel:

- the problem matters in smart-home or health-oriented deployment
- existing methods fail for one crisp reason
- the proposed system is physically grounded rather than heuristic
- the implementation is practical, not merely simulated

## 2. Paper-by-Paper Roles

### AutoLoc

Narrative role:
calibration and dual-position estimation under missing prior knowledge.

Core story:
existing tracking assumes known device position and user initial position; AutoLoc reframes joint estimation as feature reconstruction and matching, then reduces search cost with alternating iteration.

What to borrow:

- coupled-variable challenge framing
- reconstruction instead of direct regression
- complexity reduction as a second explicit challenge

### DuTrack

Narrative role:
long-term tracking under cumulative drift.

Core story:
velocity-only Wi-Fi tracking drifts over time; acoustic constraints provide absolute corrections; the system fuses electromagnetic and mechanical wave geometry into one optimization model.

What to borrow:

- long-term reliability framing
- multimodal correction rather than simple feature concatenation
- strong contrast against accumulation error

### Secur-Fi

Narrative role:
security and anti-sensing defense.

Core story:
through-wall Wi-Fi sensing is useful but dangerous; the system intentionally perturbs signals for attackers while preserving recoverability for authorized users through codebooks and delay-aware recovery.

What to borrow:

- threat-first introduction
- dual requirement framing: block attackers while preserving authorized utility
- mechanism phrased as controlled signal transformation plus recovery

### UNI-FI

Narrative role:
framework and unification paper.

Core story:
single-task sensing results are hard to integrate; the paper formalizes Wi-Fi sensing as forward and inverse models, then builds a scalable pipeline that composes multiple tasks through a shared representation.

What to borrow:

- formalization-heavy introduction
- explicit research questions
- framework language: boundaries, sets, model network, scalability

### WSTrack

Narrative role:
single-link multimodal tracking with limited devices.

Core story:
voice assistants already have Wi-Fi and microphones, but prior methods either need voice commands or expensive calibration; WSTrack extracts AoA from footsteps and fuses it with Wi-Fi-derived motion constraints.

What to borrow:

- limited-device argument
- natural multimodal hardware co-location
- challenge decomposition into extraction, fusion, and initialization

## 3. Shared Narrative Skeleton

Most papers in this corpus follow this front-half structure:

1. `Background and Motivation`
   Explain the application pull and why Wi-Fi sensing is attractive.

2. `Gap or Limitation`
   Identify one sharp missing capability in current systems.

3. `Basic Idea` or `In a Nutshell`
   State the system in one paragraph as a conceptual inversion of the gap.

4. `Challenges and Solutions`
   Usually 2 to 3 challenges, each tied to one named method.

5. `Contributions`
   Usually theory or model, method or pipeline, implementation or evaluation.

6. `Roadmap`
   One short paragraph that previews the remaining sections.

## 4. Shared Technical Logic

The local papers tend to reason in this order:

1. observable signal change
2. physical interpretation
3. feature construction
4. ambiguity or deployment problem
5. algorithmic resolution
6. system module
7. evaluation metric

This is important. Do not jump directly from raw CSI to a model without explaining what the signal physically encodes.

## 5. Recurrent Challenge Types

The corpus repeatedly uses a small set of challenge patterns:

- variable coupling
- long-term drift
- weak or sparse measurements
- asynchronous modalities
- high search complexity
- lack of calibration
- limited number of devices or antennas
- adversarial observability or privacy leakage
- poor extensibility across tasks

When drafting a new paper, choose only the challenges that are truly central. Two or three strong challenges are more persuasive than five weak ones.

## 6. Common Solution Archetypes

The papers repeatedly solve those challenges with a few reusable moves:

- reconstruct latent features and match them to observations
- fuse complementary modalities with different observability
- reduce search spaces by exploiting geometry or lower-dimensional structure
- transform a difficult physical model into a learnable pipeline
- generate controlled perturbations and then recover signals for authorized users
- define a unified feature or event abstraction to integrate tasks

## 7. Writing Style Markers

The local style prefers:

- short topic sentences before detail
- explicit challenge names
- causal transitions
- deployment-oriented justification
- frequent reminders that the system uses commercial devices
- compact contribution bullets with quantitative outcomes

The prose often relies on sentence stems like these:

- `However, existing systems...`
- `This motivates the need for...`
- `The core insight is...`
- `To address this challenge, we...`
- `Based on ... , we ...`
- `We implement the prototype on commercial off-the-shelf devices and ...`
- `Experimental results show that ...`

Do not copy these mechanically. Use them as rhythm, not as a fixed template.

## 8. Evaluation Expectations

The corpus usually expects:

- implementation details with hardware and software stack
- overall performance first
- comparison against representative baselines
- parameter or ablation study
- practical metrics such as median error, average error, accuracy, robustness, or recovery quality

If a draft lacks implementation realism, the style will feel wrong even if the language sounds similar.
